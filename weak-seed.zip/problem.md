# Weak Seed  (crypto · medium)

A wallet's signing library seeded its ECDSA nonce from a tiny **startup counter** instead of
real entropy. For the signature below, the nonce was

```text
k = sha256(decimal_string(counter)) mod n
```

with `counter` an integer in `[0, nonce_max_counter)`. That search space is small enough to
walk.

## Objective

Recover the wallet's **private key** `d` and submit it:

```text
SCAN{0x<private_key_hex>}
```
Format: `^SCAN\{0x[0-9a-f]{64}\}$` (lowercase, 64 hex, 0x included).

## Notes
- Standard secp256k1; `n` is the curve order; values are 32-byte big-endian hex.
- `challenge.json` gives the public key, the signature `(z, r, s)`, and `nonce_max_counter`.
- Find the `counter` whose nonce reproduces `r`, then recover `d`. Verify `d · G` = public key.
