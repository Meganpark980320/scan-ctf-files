#!/usr/bin/env python3
import re, sys
PATTERN = re.compile(r"^SCAN\{0x[0-9a-f]{64}\}$")
def is_valid(f): return bool(PATTERN.fullmatch(f))
if __name__=="__main__":
    f=sys.argv[1] if len(sys.argv)>1 else input("flag: ")
    print("format looks valid" if is_valid(f) else "format INVALID"); sys.exit(0 if is_valid(f) else 1)
