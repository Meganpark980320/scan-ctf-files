# Paper Crown

Meridian 체인에서 한 자산 프록시가 짧은 시간 동안 `SmokeLogic`으로 바뀌었다가
원래 구현으로 돌아왔습니다. 같은 구간의 receipt에는 표준 ERC-20 `Transfer`처럼 보이는
로그가 남아 있지만, 그 로그만으로 실제 잔고 이동을 믿을 수는 없습니다.

당신의 목표는 **실제로 잔고를 받은 EOA 주소** 하나를 찾아
`SCAN{0x...}` 형식으로 제출하는 것입니다.

## 제공 자료

- `case.json`: 조사 대상 proxy·reserve·두 implementation word와 관측 범위
- `contracts.json`: 주소가 EOA인지 contract인지의 분류
- `storage_layout.json`, `slot_preimages.json`: raw storage slot의 의미
- `traces.json`: 실행 frame과 opcode 관측값
- `state_diffs.json`: 각 transaction 종료 시점의 committed storage 차이
- `receipts.json`: committed receipt log 사본

배열의 파일상 순서는 의미가 없습니다. transaction은
`(block_number, transaction_index, tx_hash)`, 한 transaction 안의 operation은 `step`
오름차순으로 해석하세요.

## 판정 규칙

아래 조건을 **모두** 만족하는 유일한 EOA `X`를 찾으세요.

1. `case.json`의 target proxy에서, 같은 `root_status == "SUCCESS"` transaction 안에
   implementation slot의 committed `SSTORE` 두 개가 순서대로 있습니다.
   첫 write는 `stable_implementation_word → temporary_implementation_word`, 뒤 write는
   `temporary_implementation_word → stable_implementation_word`여야 합니다. 이 두 step
   사이를 implementation window라고 부릅니다.
2. 그 window 안에 `call_type == "DELEGATECALL"`,
   `code_address == temporary_implementation`, `storage_address == target_proxy`,
   `status == "SUCCESS"`인 frame이 있습니다. frame 자체와 모든 descendant frame의
   operation만 이 frame의 effect로 셉니다. frame은 `enter_step`과 `exit_step` 전체가
   window 안에 있어야 합니다.
3. 위 effect에서 `committed: true`인 `SSTORE`만 사용합니다. 같은 `(storage_address, slot)`을
   여러 번 썼다면 step 기준 첫 `before`와 마지막 `after`의 차이가 net change입니다.
   `slot_preimages.json`으로 `balances[address]`인 slot만 골라야 합니다.
4. target proxy의 `balances[reserve]` net change가 `-A`이고 `A > 0`일 때,
   **EOA** `X`의 `balances[X]` net change가 정확히 `+A`여야 합니다. 해당 effect의
   `totalSupply` net change는 0이어야 합니다.
5. 이 balance change의 transaction 종료값이 `state_diffs.json`과 맞아야 합니다.
   중간에 바뀌었다가 원래 값으로 돌아온 slot은 종료 diff에 나타나지 않는 것이 정상입니다.

`DELEGATECALL`에서는 `code_address`가 실행한 코드이고 `storage_address`가 실제로 읽고
쓴 storage입니다. 따라서 같은 code address라도 storage context가 다르면 target proxy의
잔고 증거가 아닙니다.

## 로그에 대한 주의

`LOG3`와 ERC-20 `Transfer` topic은 receipt에 남은 **주장**일 뿐, 이 문제에서 답을 정하는
증거가 아닙니다. `indexed_to`가 가리키는 주소를 그대로 제출하지 말고, 위 storage 규칙과
state diff를 끝까지 확인하세요. `root_status == "REVERTED"`이거나 `committed: false`인
관측은 어떤 상태 효과도 남기지 않습니다.

제출 예시(형식 예시일 뿐 정답과 무관):

```text
SCAN{0x0123456789abcdef0123456789abcdef01234567}
```
