#!/usr/bin/env python3
"""Local format checker; this validates syntax only, not the answer."""

from __future__ import annotations

import re


FLAG = re.compile(r"^SCAN\{0x[0-9a-f]{40}\}$")


def is_valid(candidate: str) -> bool:
    return bool(FLAG.fullmatch(candidate))


if __name__ == "__main__":
    print("valid" if is_valid(input()) else "invalid")
