# Paper Crown

`problem.md`부터 읽고, 모든 JSON 파일을 같은 디렉터리에 둔 채로 분석하세요.
이 번들은 외부 RPC·블록 탐색기 없이 완결됩니다.

제출 형식만 빠르게 확인하려면 다음을 실행할 수 있습니다.

```bash
python3 check_format.py
```

형식 검사기는 정답 여부를 판정하지 않습니다.
