# Reused  (crypto · medium)

A wallet on a secp256k1 chain signed two different transactions. Its signing device had a
broken RNG and **reused the same nonce** for both — the classic mistake behind real-world
key thefts (the 2013 Android Bitcoin wallet bug, among others).

`challenge.json` gives the wallet's public key and the two ECDSA signatures. Both share the
same `r`, which is the tell that the nonce was reused.

## Objective

Recover the wallet's **private key** `d` and submit it:

```text
SCAN{0x<private_key_hex>}
```
Format: `^SCAN\{0x[0-9a-f]{64}\}$` (lowercase, 64 hex chars, 0x included).

## Notes

- Standard secp256k1 (`n` is the curve order). All values are 32-byte big-endian hex.
- `z` is the message hash each signature was computed over; `(r, s)` is the signature.
- Verify yourself: `d · G` must equal the given public key.
- `check_format.py` only checks the flag shape.
