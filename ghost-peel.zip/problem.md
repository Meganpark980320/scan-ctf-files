# Ghost Peel

An exchange treasury reported that one of its UTXOs was stolen. The thief split the
loot at the very first hop and laundered the two halves down separate peel chains —
one longer than the other — before quietly recombining them and sitting on the result.

You have a complete, self-contained export of the observation window (`input.json`);
**do not use a public block explorer**. The stolen outpoint is `start_outpoint`.

## Objective

Find the wallet the thief recombined the stolen funds into, and submit it as:

```text
SCAN{<lowercase_regtest_address>}
```

Where the two chains come back together is a single transaction that spends coins
from **both** halves at once — the moment the thief reveals common control of them.
Follow the money from `start_outpoint` down both branches and identify the address
that first holds the recombined funds.

Notes:

- The export is complete within the stated window; every amount is an exact satoshi,
  and `transactions` is deliberately **not** in chronological order (`height` and
  `tx_index` give the true order).
- The chain carries other activity too — unrelated clusters, and transactions that
  merge coins which do **not** descend from **both** halves of the split (e.g. two
  coins from the same half, or coins from an unrelated source). It is provenance from
  `start_outpoint` that decides the answer, not the mere shape of a transaction.
- If more than one address ever ends up holding funds from both halves, the earliest
  one by block order is the answer.
- `schema.json` documents the input shape. `check_format.py` only checks the flag
  shape; it does not know the answer.
