# Ghost Peel

An exchange treasury reported that one of its UTXOs was stolen and then split into
two peel chains. You have a complete, self-contained export of the observation
window; **do not use a public block explorer**.

The starting outpoint is in `input.json` as `start_outpoint`.

## Objective

Return the beneficiary address as:

```text
SCAN{<lowercase_regtest_address>}
```

For this challenge, the beneficiary is defined mechanically:

1. Find the unique transaction that spends `start_outpoint`. It has exactly two
   outputs, numbered `0` and `1`; these create root branches 0 and 1.
2. An output is a descendant of a branch when its transaction consumes an output
   already descended from that branch. If a transaction has several inputs, each
   output inherits the union of their branch identities.
3. Consider only descendants of those two root branches. Sort output events by
   `(height, tx_index, txid, vout)`. For each address, accumulate the branch
   identities of all direct descendant outputs it has received. The beneficiary is
   the address at the first event where its accumulated set becomes `{0,1}`; the
   two outputs may be in different transactions.

`transactions` is intentionally not ordered. `height` and `tx_index` determine
chronology. The export is complete within the stated observation window, and all
amounts are exact satoshis. All outputs are intentionally unlabeled: do not prune
one based on amount or a presumed merchant/change role. `beneficiary` is a
task-defined convergence address, not an inference about whether it later spends
funds onward.

`schema.json` documents the input shape. `check_format.py` only checks the flag
shape; it does not know the answer.
