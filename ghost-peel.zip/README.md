# Ghost Peel

Start with [problem.md](problem.md). Everything needed to solve the challenge is
inside this directory:

- `input.json` — complete synthetic regtest transaction export
- `schema.json` — input contract
- `manifest.json` — SHA-256 integrity checks for the public files
- `check_format.py` — local flag-shape checker only

No network access or public block explorer is required.

