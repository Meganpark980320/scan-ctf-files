#!/usr/bin/env python3
"""Local flag-shape checker. It deliberately does not contain the answer."""

from __future__ import annotations

import re
import sys

FLAG_RE = re.compile(r"^SCAN\{bcrt1[qpzry9x8gf2tvdw0s3jn54khce6mua7l]{20,90}\}$")


def is_valid(flag: str) -> bool:
    return bool(FLAG_RE.fullmatch(flag))


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        print(f"usage: {argv[0]} 'SCAN{{...}}'", file=sys.stderr)
        return 2
    if is_valid(argv[1]):
        print("format looks valid")
        return 0
    print("invalid flag format", file=sys.stderr)
    return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))

