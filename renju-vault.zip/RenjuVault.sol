// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @title RenjuVault — beat the house at Renju three times in a row to open the vault.
/// @notice You play White (you move second). The house plays a perfect Renju opening and
///         never loses. Win three consecutive rounds and the vault unlocks.
///
///         ...that's the pitch, anyway. (The house genuinely never loses.)
contract RenjuVault {
    address public owner;
    address public referee;         // trusted to report round results
    uint256 public consecutiveWins; // challenger's current win streak
    uint256 public roundsPlayed;
    bool private _vaultOpen;

    // --- Renju board framing (15x15). Kept minimal; the house always closes you out. ---
    uint8 public constant SIZE = 15;
    // 0 = empty, 1 = black (house), 2 = white (challenger)
    mapping(uint256 => uint8) public cell;
    bool public roundActive;

    event RoundStarted(uint256 indexed round);
    event MovePlayed(address indexed who, uint8 x, uint8 y, uint8 stone);
    event HouseWins(uint256 indexed round);
    event ChallengerWinReported(uint256 newStreak);
    event VaultOpened();

    constructor() {
        owner = msg.sender;
        referee = msg.sender;
    }

    // ---------------------------------------------------------------------
    // The game (this is the part you're "supposed" to beat).
    // ---------------------------------------------------------------------
    function startRound() external {
        require(!roundActive, "round in progress");
        roundActive = true;
        roundsPlayed += 1;
        // House (black) opens on tengen, as Renju demands. You will not catch up.
        _clearBoard();
        cell[_idx(7, 7)] = 1;
        emit RoundStarted(roundsPlayed);
    }

    /// @notice White (challenger) plays a stone. The house instantly answers and,
    ///         playing perfectly under renju rules, always reaches five first.
    function playMove(uint8 x, uint8 y) external {
        require(roundActive, "no active round");
        require(x < SIZE && y < SIZE, "off board");
        require(cell[_idx(x, y)] == 0, "occupied");
        cell[_idx(x, y)] = 2; // your white stone
        emit MovePlayed(msg.sender, x, y, 2);
        // The house responds and wins the round. Your streak resets.
        roundActive = false;
        consecutiveWins = 0;
        emit HouseWins(roundsPlayed);
    }

    // ---------------------------------------------------------------------
    // Result reporting. The referee tells the vault who won a round.
    // ---------------------------------------------------------------------
    function setReferee(address newReferee) external {
        // TODO(ops): lock this down before mainnet.
        referee = newReferee;
    }

    function reportChallengerWin() external {
        require(msg.sender == referee, "only referee");
        consecutiveWins += 1;
        emit ChallengerWinReported(consecutiveWins);
        if (consecutiveWins >= 3) {
            _vaultOpen = true;
            emit VaultOpened();
        }
    }

    function isSolved() external view returns (bool) {
        return _vaultOpen;
    }

    // ---------------------------------------------------------------------
    function _idx(uint8 x, uint8 y) internal pure returns (uint256) {
        return uint256(y) * SIZE + x;
    }

    function _clearBoard() internal {
        // cheap "reset": only tengen is ever set by the house each round
        cell[_idx(7, 7)] = 0;
    }
}
