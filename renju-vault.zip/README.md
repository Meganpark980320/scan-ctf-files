# Renju Vault  (on-chain · exploit)

The house built an on-chain vault and locked it behind a game of **Renju** (gomoku with
the standard renju rules). Beat the house **three rounds in a row** and the vault opens.

You play **White** — you always move second. The house opens on tengen and plays a perfect
renju game. It does not lose.

## How to play

This is a **live** challenge. You interact with a real EVM node.

1. Get your own instance:
   ```
   curl -s -X POST https://registered-citysearch-interim-oscar.trycloudflare.com/launch -H "Content-Type: application/json" -d '{"team":"YOURNAME"}'
   ```
   You get back your vault `address`, a funded `player_key`, and the RPC URL.
2. Use that URL as an EVM RPC endpoint (cast, web3.py, ethers, …) to interact with your vault:
   ```
   cast call <address> "isSolved()(bool)" --rpc-url https://registered-citysearch-interim-oscar.trycloudflare.com/
   cast call <address> "consecutiveWins()(uint256)" --rpc-url https://registered-citysearch-interim-oscar.trycloudflare.com/
   cast send <address> "startRound()" --rpc-url https://registered-citysearch-interim-oscar.trycloudflare.com/ --private-key <player_key>
   cast send <address> "playMove(uint8,uint8)" 3 3 --rpc-url https://registered-citysearch-interim-oscar.trycloudflare.com/ --private-key <player_key>
   ```
3. When your vault reports `isSolved() == true`, collect the flag:
   ```
   curl -s "https://registered-citysearch-interim-oscar.trycloudflare.com/flag?team=YOURNAME"
   ```

The contract source is included (`RenjuVault.sol`) — read it carefully.

Flag format: `SCAN{...}`.
