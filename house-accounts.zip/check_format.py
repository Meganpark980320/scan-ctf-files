#!/usr/bin/env python3
"""Flag-shape checker for House Accounts. Does NOT know the answer."""
import re, sys
PATTERN = re.compile(r"^SCAN\{[a-z0-9-]+\}$")
def is_valid(flag): return bool(PATTERN.fullmatch(flag))
if __name__ == "__main__":
    f = sys.argv[1] if len(sys.argv) > 1 else input("flag: ")
    print("format looks valid" if is_valid(f) else "format INVALID"); sys.exit(0 if is_valid(f) else 1)
