# House Accounts  (attribution · medium)

Stolen funds were cashed out at a **centralized exchange**. Several exchanges operate on
this chain. Your job is attribution: name the exchange that received the stolen funds.

You have a complete, self-contained export (`evidence.json.gz`): value `transfers`, plus
`labels` for known addresses (exchange hot wallets, a mixer, …). The stolen funds' entry
point is in `anchor`. **Do not use a public block explorer.**

## How exchanges look on-chain

An exchange gives every customer their own **deposit address**, then periodically **sweeps**
all of those deposit addresses into a single **hot wallet**. So a hot wallet is fed by *many*
distinct deposit addresses — that fan-in is how you recognize (and attribute) one. The
individual deposit addresses are **not** labeled; only the hot wallets are.

## Objective

Trace the stolen funds to the exchange **deposit address** they landed in, work out which
exchange that deposit address belongs to, and submit that exchange's entity slug:

```text
SCAN{<lowercase_entity_slug>}
```
Format: `^SCAN\{[a-z0-9-]+\}$`.

## Notes

- Self-contained; `block` gives ordering, amounts are integer wei.
- Not every labeled address is your answer — one of them is a mixer, not an exchange.
- The largest / busiest exchange is not automatically the one you want. And the stolen funds
  may pass through personal wallets (which are **not** exchanges) before reaching a real
  deposit address. Attribute by provenance + the deposit-sweep pattern, not by size.
