# Equal Footing  (CoinJoin demixing · medium-hard)

Stolen BTC was pushed through a **CoinJoin** — a single transaction that pays out many
**equal-value** outputs so that, inside that transaction, you cannot tell which input
became which output. The operator later consolidated their share and cashed out.

You have a complete, self-contained export of the window (`input.json`). **Do not use a
public block explorer.** The stolen outpoint is `start_outpoint`.

## Objective

Find the address the stolen funds were finally **cashed out** to, and submit it:

```text
SCAN{<lowercase_regtest_address>}
```

The CoinJoin itself won't hand you the link. A mixer only hides what happens *inside* the
join — everything the operator did *before* funding it and *after* pulling their coins back
out is still on the chain. Combine those to pin down which post-mix consolidation is the
stolen funds', and where it went.

## Notes

- Self-contained; `height`/`tx_index` give the true order (the array is not chronological).
  All amounts are exact satoshis; `schema.json` documents the shape.
- The join mixes several participants. More than one deposited a look-alike amount, so the
  amount pattern alone leaves more than one candidate — you'll need another thread to decide
  between them.
- `check_format.py` only checks the flag shape; it does not know the answer.
