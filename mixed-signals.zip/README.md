# Mixed Signals  (mixer demixing · medium-hard)

## Scenario
Stolen funds were laundered through a fixed-denomination contract mixer (Tornado-style).
By design the mixer breaks the on-chain link between a **deposit** and a **withdrawal** —
knowing a deposit tells you nothing about which withdrawal is "yours."

But a mixer only anonymizes what happens *inside* it. The wallets an operator uses to
interact with it — who funds the deposit, who pays the gas to pull the funds back out —
still live on the open chain. Our monitoring captured the mixer's complete event log plus
the surrounding transfers.

## Given
- `evidence.json.gz` — self-contained JSON:
  - `deposits[]` — `depositor` (EOA that deposited), `pool_eth`, `block`, `commitment`
  - `withdrawals[]` — `submitter` (EOA that sent the withdrawal tx and paid its gas),
    `recipient` (where the funds went), `relayer` (a relay service, or `null` if
    self-submitted), `fee_eth`, `block`, `nullifier`
  - `transfers[]` — plain value transfers for context (`from`, `to`, `value_eth`, `block`)
  - `mixer`, and `anchor.stolen_funds_arrived_at` — the wallet the stolen funds landed in.

## Task
Find the address the stolen funds were **withdrawn to** — the mixer exit the operator
controls — and submit it as:

```text
SCAN{<lowercase_address>}
```
Format: `^0x[0-9a-f]{40}$` (lowercase, 0x included).

## Notes
- Self-contained. No external explorer / live data needed.
- Every withdrawal in a pool moves the **same** amount, and many happen close together in
  time — so neither the amount nor "the withdrawal right after the deposit" will single one
  out. A relay service submits most withdrawals; some are self-submitted.
- Plenty of wallets brush up against the attacker. What matters is *how the wallets around
  the mixer were funded* and *who actually pulled the funds out* — not merely who received a
  transfer from whom.
