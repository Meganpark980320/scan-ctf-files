#!/usr/bin/env python3
"""Flag-shape checker for Mixed Signals. Does NOT know the answer."""
import re, sys

PATTERN = re.compile(r"^SCAN\{0x[0-9a-f]{40}\}$")

def is_valid(flag: str) -> bool:
    return bool(PATTERN.fullmatch(flag))

if __name__ == "__main__":
    f = sys.argv[1] if len(sys.argv) > 1 else input("flag: ")
    print("format looks valid" if is_valid(f) else "format INVALID")
    sys.exit(0 if is_valid(f) else 1)
