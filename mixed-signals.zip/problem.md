# Mixed Signals  (mixer demixing · medium)

## Scenario
Stolen funds were laundered through a fixed-denomination contract mixer (Tornado-style).
By design the mixer breaks the on-chain link between a **deposit** and a **withdrawal** —
knowing a deposit tells you nothing about which withdrawal is "yours."

But a mixer only anonymizes what happens *inside* it. The wallets an operator uses around
it — the wallet that funds the deposit, and the wallet that pays the gas to pull the funds
back out — still live on the open chain, and here they trace back to the same source.

## Given
`evidence.json.gz` — self-contained JSON:
- `deposits[]` — `depositor` (EOA that deposited), `pool_wei`, `block`, `commitment`
- `withdrawals[]` — `submitter` (EOA that sent the withdrawal tx and paid its gas),
  `recipient` (where the funds went), `relayer` (a relay service, or `null` if
  self-submitted), `fee_wei`, `block`, `nullifier`
- `transfers[]` — plain value transfers for context/clustering: `from`, `to`, `value_wei`, `block`
- `mixer`, and `anchor.stolen_funds_arrived_at` — the wallet the stolen funds landed in.

All amounts are integer **wei** (`decimals: 18`); never use floats.

## Objective
Find the mixer **exit** — the address the stolen funds were **withdrawn to** — and submit it:

```text
SCAN{<lowercase_address>}
```
Format: `^SCAN\{0x[0-9a-f]{40}\}$`. **Submit the withdrawal's `recipient`** (where the funds
landed), not the wallet that submitted the withdrawal.

## Notes
- Self-contained. No external explorer / live data needed.
- Every withdrawal in a pool moves the **same** amount, and many happen close together in
  time — neither the amount nor "the withdrawal right after the deposit" will single one out.
  A relay service submits most withdrawals; several are self-submitted.
- Plenty of wallets brush up against the attacker. What links a deposit to a withdrawal here
  is *how the wallets around the mixer were funded* — not merely who received a transfer from
  whom, and not the amounts (which collide by design).
