# Affine Reclaim

이 문제는 source와 ELF를 제공하지 않는 live / black-box native service다. CTFd가 주는 TCP endpoint에
접속하면 connection마다 독립 worker가 생긴다. 목표는 banner의 recovery case를 자신이 고른 beneficiary로
`SETTLED`에 도달시키고 응답의 flag를 얻는 것이다.

    nc <HOST> <PORT>

일반 외부 compliance attestation은 sandbox에 존재하지 않는다. 대신 서비스에는 상태를 전혀 바꾸지 않는
coupled allocator calibration bench와 two-epoch phase trace가 있으며, `protocol.md`가 그 수학적 contract를
정의한다. raw address,
debugger, core dump, source archive는 주어지지 않는다.

`problem.md`, `protocol.md`, `sample-session.txt`를 먼저 읽어라. malformed request나 보통의 command
rejection은 worker를 유지한다. disconnect, 45초 idle timeout, overlong line, 또는 420초 worker lifetime
종료 뒤에는 새 connection에서 다시 시작해야 한다. 같은 service instance의 calibration router는 worker를
넘어 유지되지만, recovery case와 quote ledger는 절대 공유되지 않는다.

제출 형식은 `SCAN{...}`이며 `check_format.py`는 형식만 확인한다.
