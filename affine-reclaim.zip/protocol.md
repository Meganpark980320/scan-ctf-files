# Affine Reclaim wire protocol

연결 직후 서버는 다음 두 줄을 보낸다.

    AFFINE-RECLAIM/1 build=<build-id> target=<case-id> amount=<integer>
    worker=fresh protocol=LINE/1 hint=HELP router=calibration

각 request와 response는 최대 512 byte의 ASCII 한 줄이다. 공백으로 field를 나눈다. beneficiary와 memo는
`[a-z0-9_-]`만 허용한다. beneficiary 길이는 3–24, memo 길이는 1–64이며, 모든 token은 case-sensitive다.
16-hex field는 lowercase hexadecimal exactly 16자다.

## Commands

    BEGIN <case-id> <beneficiary>
    STATUS <case-id>
    CAL <route0-hex16> <route1-hex16> <route2-hex16> <route3-hex16> <route4-hex16> <route5-hex16>
    QUOTE <tier> <lane> <beneficiary> <continuity-hex16> <memo> <route-hex16>
    ATTACH <case-id> <review|hold|escrow|archive|appeal|reserve> <quote-ref>
    VOID <quote-ref>
    RELEASE <case-id> <review|hold|escrow|archive|appeal|reserve>
    PHASE <case-id> <0..5>
    RETURN <quote-ref>
    RETRY <case-id>
    ATTEST <case-id> <signature>
    QUIT

`BEGIN`은 banner의 target case에 대해 한 번만 가능하다. `CAL`은 case id를 받지 않는 service-wide bench다.
`QUOTE`, `VOID`, `RETURN`은 worker-scoped operation이다.

## Lifecycle

    NEW → OPEN → DRAINING → RECLAIM_0 → … → RECLAIM_5
        → R1_RETURN → RECONCILE_0 → … → RECONCILE_5 → FINAL_READY → SETTLED

`OPEN`에서 C1 evidence를 census, attach, retire한다. 여섯 role의 성공한 binding만 `VOID`할 수 있으며, 그
여섯 ref의 VOID 순서는 자유롭다. 모두 retire된 뒤 six docket을 각각 한 번 `RELEASE`한다. release 명령의
role 순서도 자유롭다.

두 ordering은 서로 다르다.

- C2와 C3의 logical source 순서는 attached C1 ref의 오름차순이다.
- retained arena는 가장 최근에 `RELEASE` 또는 `RETURN`한 cell부터 재사용하는 stack-like LIFO 방식이다.

따라서 logical folio order와 physical reclaimed-cell order를 따로 모델링해야 한다. 여섯 C2가 staged되면
`R1_RETURN`이 열린다. `RETURN`은 live C2 evidence만 받아 **그 C2 quote가 현재 점유한 reclaimed storage**를
다시 available하게 만든다. 정상 first relay에서는 그것이 original logical source의 storage와 일치하지만,
crossed relay에서는 다를 수 있다. `RETURN`은 C3 target을 직접 지정하거나 retarget하지 않는다. 여섯 C2를
모두 return한 뒤 C3 reconciliation epoch가 시작한다.

## Quotes and evidence

모든 `QUOTE`는 tier `t0|t1|t2`, lane `l0|l1|l2`, beneficiary, continuity, memo, route를 받는다. memo
길이만 receipt class를 정한다.

| memo 길이 | receipt | 허용 window |
|---:|---|---|
| 1–16 | c1 | OPEN |
| 17–32 | c2 | RECLAIM_0 … RECLAIM_5 |
| 33–64 | c3 | RECONCILE_0 … RECONCILE_5 |

C1 ref는 worker-local `Q0`부터 `Q7`까지 lowest-free 방식으로 발급된다.

    OK quote=Q<n> revision=<positive integer> receipt=c1 docket=census

`ATTACH` 전에 C1 여덟 개가 모두 live여야 한다. 각 role은 서로 다른 target C1 cell 하나를 가진다. role의
잘못된 ref에 대한 `E_AUDIT <role>-cell-mismatch`는 state를 바꾸지 않는 census probe다. 원래 C1 ref가
retire되면 C2, 그리고 C3가 그 folio를 순서대로 재사용하며 revision을 하나씩 증가시킨다.

Card profile은 다음과 같다.

| role | Card | tier | lane |
|---|---|---|---|
| review, archive | A | t2 | l0 |
| hold, appeal | B | t1 | l2 |
| escrow, reserve | C | t0 | l1 |

C2 profile은 original logical source role의 card다. C3 profile은 아래 `PHASE`가 정의하는 **target role**의
card다. 두 relay 전체는 banner continuity와 동일한 continuity 및 하나의 동일 beneficiary를 사용해야 한다.
C2/C3 receipt는 input route의 정오답, locator, reclaimed storage, 또는 raw view를 말해 주지 않는다.

    OK quote=Q<n> revision=<positive integer> receipt=c2 docket=reclaim lane=<0..5>
    OK quote=Q<n> revision=<positive integer> receipt=c3 docket=reconcile lane=<0..5>

각 epoch의 여섯 route가 모두 staged된 뒤에만 route vector와 physical handoff를 함께 latch한다. 잘못된 input,
release ordering, 또는 return ordering을 같은 worker에서 고칠 수는 없다.

## Coupled calibration router

`route`와 `locator`는 주소가 아니라 protocol-level 64-bit opaque label이다. service instance가 시작할 때
두 64-bit GF(2) linear map `A`, `B`와 lane별 64-bit bias `b_i`를 만든다. instance가 살아 있는 동안 모든
fresh worker에 같은 router가 적용된다.

하나의 `CAL`은 six-route vector `R=(r_0,…,r_5)`를 받고 six-locator vector `L=(L_0,…,L_5)`를 돌려준다.

    CAL r0 r1 r2 r3 r4 r5
    OK cal routes=r0,r1,r2,r3,r4,r5 locators=L0,L1,L2,L3,L4,L5

64-bit input/output를 bit 0이 least-significant bit인 binary column vector로 읽으면 정확한 contract는 다음과
같다. index는 modulo 6이다.

    L_i(R) = A · r_i XOR B · r_(i+1) XOR b_i

`A`, `B`, bias는 flag-derived secret이 아니다. six 64-bit input에서 six 64-bit output으로 가는 전체
384-bit affine transform은 bijection이며, `CAL` output만으로 완전히 관측 가능하다. `CAL`은 `BEGIN` 전에도
호출할 수 있고 worker state, quote ledger, arena, quota를 전혀 바꾸지 않는다.

`RECLAIM_n` 또는 `RECONCILE_n`의 `STATUS`는 다음 field를 보낸다.

    next_lane=<n> anchors=review:<hex16>,hold:<hex16>,escrow:<hex16>,archive:<hex16>,appeal:<hex16>,reserve:<hex16>

logical source sequence를 `s_0,…,s_5`라 하자. C2 epoch의 target locator vector는
`(anchor(s_0),…,anchor(s_5))`다. C3 epoch의 target은 `PHASE`에서 복원한 permutation `P`를 적용한
`(anchor(P(s_0)),…,anchor(P(s_5)))`다. individual C2/C3 요청은 vector equation의 부분 정답 oracle을 주지
않으며, 각 epoch의 마지막 quote 뒤에만 result가 latch된다.

## Phase trace

R1_RETURN에서 아직 아무 C2도 return하지 않았을 때 `PHASE <case> i` (`i=0..5`)를 read-only로 호출할 수 있다.
role index는 다음 순서다.

    review=0, hold=1, escrow=2, archive=3, appeal=4, reserve=5

서비스는 source role `i`에서 C3 target role `P(i)`로 가는 per-case bijection `P`를 가진다. `PHASE`는
`p_i = role_index(P(i))`에 대한 F_101 trace를 보인다.

    OK phase=i trace=x_i
    x_i = p_i + 17 · p_(i+1 mod 6) mod 101

six trace는 P를 완전히 정의한다. trace는 secret이나 flag-derived 값이 아니며 return 또는 C3 issue로 state를
바꾸지 않는다. C3 physical placement는 `RETURN` LIFO order와 이 target permutation을 함께 만족해야 한다.

## Useful status fields

    phase=NEW|OPEN|DRAINING|RECLAIM_<0..5>|R1_RETURN|RECONCILE_<0..5>|FINAL_READY|SETTLED
    <role>_evidence=none|Q<0..7>
    handoff=pending|aligned|crossed
    continuity=<16 lowercase hex>
    next_lane=<0..5> anchors=<role:hex16,...>   # issue epochs only
    phase_trace=ready                            # R1_RETURN before first RETURN

`STATUS`는 retained raw view, storage link, actual process address, individual route verdict, 또는 partial
relay latch를 공개하지 않는다.

## Error taxonomy

| Code | Meaning |
|---|---|
| E_PARSE | 문법 또는 field count 오류 |
| E_CASE | 현재 worker의 target이 아닌 case |
| E_STATE | 허용되지 않은 lifecycle/receipt window |
| E_BENEFICIARY | beneficiary token 형식 오류 |
| E_QUOTE | tier, lane, quote ref, 또는 quote liveness 오류 |
| E_MEMO | memo 형식 또는 길이 오류 |
| E_CONTINUITY | 16-hex field 형식 오류 |
| E_AUDIT | census, retirement, folio ordering, 또는 relay evidence 조건 불충족 |
| E_POLICY | final reclaim-chain acceptance 실패 |
| E_SIGNATURE | 외부 compliance signature 필요 |
| E_QUOTA | worker-local allocation quota 초과 |
| E_BUSY | service worker capacity 초과; 잠시 뒤 재연결 |
| E_TIMEOUT | 45초 idle worker timeout |

worker 전체 lifetime은 420초다. timeout 또는 disconnect 뒤에는 새 worker에서 다시 시도하면 된다.
