#!/usr/bin/env python3
"""Format-only checker for Affine Reclaim flags."""

from __future__ import annotations

import re
import sys


PATTERN = re.compile(r"^SCAN\{[a-z0-9_]{8,80}\}$")


def main() -> int:
    candidate = sys.stdin.read()
    if candidate.endswith("\n"):
        candidate = candidate[:-1]
    if candidate.endswith("\r"):
        candidate = candidate[:-1]
    if PATTERN.fullmatch(candidate):
        print("valid flag format")
        return 0
    print("invalid flag format", file=sys.stderr)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
