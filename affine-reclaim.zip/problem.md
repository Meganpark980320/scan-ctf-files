# Affine Reclaim

The recovery desk retains six independently audited dockets: review, hold, escrow, archive, appeal,
and reserve. An ordinary external attestation is unavailable in this sandbox, but the service's
allocator calibration bench is intentionally exposed for operational diagnostics.

Use the supplied endpoint and public files only. Recover the banner's case to a beneficiary you
control and submit the returned flag. There is no downloadable binary, source tree, debugger, or
state shared between fresh worker connections.
