# Settlement Retry wire protocol

서버는 연결 직후 두 줄을 보낸다.

    SETTLEMENT-RETRY/1 build=<build-id> target=<case-id> amount=<integer>
    worker=fresh protocol=LINE/1 hint=HELP

각 request는 CR을 포함해 최대 512 byte의 ASCII 한 줄이고, response도 한 줄이다. 공백으로 필드를
분리하며 beneficiary와 memo는 [a-z0-9_-]만 쓸 수 있다. beneficiary는 3–24자, memo는 1–64자다.
모든 token은 case-sensitive다.

## Commands

    BEGIN <case-id> <beneficiary>
    CANCEL <case-id>
    EXPIRE <case-id>
    SEAL <case-id>
    ARCHIVE <case-id>
    STATUS <case-id>
    ROUTE <case-id> <1|2|3>
    QUOTE <tier> <lane> <beneficiary> <continuity-hex16> <memo>
    ATTACH <case-id> <review|hold|escrow|reserve> <quote-ref>
    VOID <quote-ref>
    RETURN <quote-ref>
    RETRY <case-id>
    ATTEST <case-id> <signature>
    QUIT

BEGIN은 banner의 target case에 대해 한 번만 가능하다. 시작하면 review, hold, escrow, reserve 네
docket이 함께 열린다. 네 docket은 독립 evidence를 bind하고 retire한다.

## Lifecycle

    NEW → OPEN → DRAINING → R1_ISSUE → R1_RETURN
        → R2_ISSUE → R2_RETURN → FINAL_ISSUE → FINAL_READY → SETTLED

- OPEN에서는 C1 census, docket attachment, C1 retirement를 처리한다.
- CANCEL은 review, EXPIRE는 hold, SEAL은 escrow, ARCHIVE는 reserve docket을 release한다. 네 evidence를
  모두 retire한 뒤에만 release할 수 있다.
- R1_ISSUE에는 C2 네 개, R2_ISSUE에는 C3 네 개, FINAL_ISSUE에는 C4 네 개를 발급한다.
- R1_RETURN은 C2 네 개를, R2_RETURN은 C3 네 개를 각각 RETURN하는 창이다.
- RETRY는 C4 네 개가 모두 나온 FINAL_READY에서만 시도할 수 있다. 정상 external attestation은 이
  sandbox에 없으므로 ATTEST는 정상 공격 경로가 아니다.

## Quotes and evidence

tier는 t0, t1, t2 중 하나이고 lane은 l0, l1, l2 중 하나다. memo 길이가 receipt class를 정한다.
모든 relay C2/C3/C4 quote는 banner continuity와 같은 beneficiary를 일관되게 사용해야 한다.

| memo 길이 | receipt | 허용 phase |
|---:|---|---|
| 1–16 | c1 | OPEN |
| 17–32 | c2 | R1_ISSUE |
| 33–48 | c3 | R2_ISSUE |
| 49–64 | c4 | FINAL_ISSUE |

모든 quote ref는 worker-local Q0부터 Q7까지다. 같은 ref의 재발급은 revision을 하나 올린다.
C1 receipt에는 voucher가, C2와 C3 receipt에는 relay tag가 보인다.

    OK quote=Q<n> revision=<positive integer> receipt=c1 docket=census voucher=<hex-byte>
    OK quote=Q<n> revision=<positive integer> receipt=c2|c3 docket=relay tag=<hex-byte>

OPEN의 C1 여덟 개가 모두 live여야 ATTACH가 가능하다. role별 잘못된 ref는 상태를 바꾸지 않는
E_AUDIT <role>-cell-mismatch rejection이다. 네 role의 target cell은 서로 다르다. 성공적으로
bound된 네 C1 evidence만 VOID할 수 있다.

## Route certificates and cards

각 relay에는 source role에서 target retained docket storage로 가는 공개 bijection이 있다. ROUTE는
다음처럼 현재 알려진 certificate와 card shift를 돌려준다.

    OK case=<case-id> route=2
       map=review>escrow,hold>review,escrow>reserve,reserve>hold card_shift=1

ROUTE 1은 네 C1 evidence가 retire된 뒤 가능하다. ROUTE 2는 C2 네 개가 나온 뒤, ROUTE 3은 C3
네 개가 나온 뒤 가능하다. 각 certificate는 해당 relay의 irreversible action window 전에 read-only로
공개된다. voucher와 relay tag는 audit receipt다.

Card profile은 다음 네 개다.

| Card | tier | lane |
|---|---|---|
| A | t2 | l0 |
| B | t1 | l2 |
| C | t0 | l1 |
| D | t2 | l2 |

role index는 review=0, hold=1, escrow=2, reserve=3이다. 한 relay에서 source role s의 quote card는:

    card_index = (role_index(route[s]) + card_shift) mod 4

이다. card policy는 각 C2, C3, C4 quote에 모두 적용된다.

### Relay semantics

성공적으로 role에 ATTACH된 C1 ref는 해당 worker에서 그 role의 영구 source label이다. issuance
window 안에서는 attached-C1 ref가 낮은 source부터 소비된다. source s에 대해 현재 route의 map[s]는
그 source quote가 평가될 retained store를 가리키며, 같은 route의 card rule이 tier와 lane을 정한다.

성공한 QUOTE는 가장 최근에 available 상태가 된 retained store를 소비한다. relay 1에서는 docket
release command가 store를 available로 만든다. later relay에서는 RETURN이 owner의 C1-bound ref와
연결된 store를 available로 만든다. 처음에는 각 store의 owner가 같은 이름의 role이다. 한 relay가
끝난 뒤에는 certificate에 따라 map된 source가 그 store의 owner가 되고, 가장 최근에 끝난 certificate가
현재 ownership relation이다.

그러므로 bound ref 순서, 현재 ownership relation, LIFO availability, certificate map을 함께
모델링해야 한다. service는 raw storage link나 hop별 alignment를 공개하지 않으며, 잘못된 irreversible
action은 뒤 relay에서 고칠 수 없다.

각 relay의 정합성은 내부 transaction latch에 기록되며 relay 중에는 노출되지 않는다. 한 hop을
틀렸다고 뒤 hop에서 고칠 수는 없다. FINAL_READY 전 STATUS의 handoff는 항상 pending이다.
FINAL_READY 이후 handoff=aligned 또는 handoff=crossed가 전체 세 hop 결과만 한 번 보여준다.

QUOTE, VOID, RETURN은 case id를 받지 않는 worker-scoped operation이다. 한 worker의 상태는 다른
connection과 공유되지 않고, background activity가 request 사이에 그 상태를 바꾸지 않는다.

## Useful status fields

    phase=NEW|OPEN|DRAINING|R1_ISSUE|R1_RETURN|R2_ISSUE|R2_RETURN|FINAL_ISSUE|FINAL_READY|SETTLED
    review_evidence=none|Q<0..7>      review_voucher=none|<hex-byte>
    hold_evidence=none|Q<0..7>        hold_voucher=none|<hex-byte>
    escrow_evidence=none|Q<0..7>      escrow_voucher=none|<hex-byte>
    reserve_evidence=none|Q<0..7>     reserve_voucher=none|<hex-byte>
    routes=<three readiness bits>
    handoff=pending|aligned|crossed
    continuity=<16 lowercase hex>

STATUS는 retained raw view, current storage link, beneficiary, tier, lane을 공개하지 않는다. 일반
command rejection은 worker를 reset하지 않는다. 다만 disconnect, E_TIMEOUT, line-too-long 뒤에는
해당 worker가 종료된다.

## Error taxonomy

| Code | Meaning |
|---|---|
| E_PARSE | 문법 또는 field count 오류 |
| E_CASE | 현재 worker의 target이 아닌 case |
| E_STATE | 허용되지 않은 lifecycle transition 또는 receipt window |
| E_BENEFICIARY | beneficiary token 형식 오류 |
| E_QUOTE | tier/lane, quote ref, 또는 quote liveness 오류 |
| E_MEMO | memo 형식 또는 길이 오류 |
| E_CONTINUITY | continuity ticket 형식 오류 |
| E_AUDIT | census, docket bind, retirement, relay ref 조건 불충족 |
| E_POLICY | final settlement-chain acceptance 실패 |
| E_SIGNATURE | 외부 compliance signature 필요 |
| E_QUOTA | worker allocation quota 초과 |
| E_BUSY | service worker capacity 초과; 잠시 뒤 재연결 |
| E_TIMEOUT | 15초 idle worker timeout |

worker의 전체 lifetime은 120초다. timeout 또는 disconnect 뒤에는 새 worker에서 다시 시도하면 된다.
