#!/usr/bin/env python3
"""Participant-side syntax checker; this does not validate the real flag."""

from __future__ import annotations

import re


FLAG = re.compile(r"^SCAN\{[a-z0-9_]{8,80}\}$")


def is_valid(value: str) -> bool:
    return FLAG.fullmatch(value) is not None


if __name__ == "__main__":
    import sys

    raise SystemExit(0 if len(sys.argv) == 2 and is_valid(sys.argv[1]) else 1)
