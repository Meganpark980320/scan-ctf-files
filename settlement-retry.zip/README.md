# Settlement Retry

이 문제는 live / black-box native service다. 참가자에게 제공되는 것은 이 문서뿐이며 source와 ELF는
배포하지 않는다. CTFd에 표시된 TCP endpoint에 연결하면 매 connection마다 독립적인 새 worker가 생긴다.

목표는 banner가 알려 주는 recovery case의 review, hold, escrow, reserve 네 docket을 내가 제어하는
beneficiary로 SETTLED 상태에 도달시키는 것이다. 정상 compliance attestation은 제공되지 않으며,
성공 응답이 flag를 돌려준다.

    nc <HOST> <PORT>

먼저 protocol.md와 sample-session.txt를 읽어라. 이 서비스는 주소, stack trace, crash dump를 주지
않는다. 대신 normal operation용 evidence receipt와 read-only route certificate를 제공한다.
malformed request나 일반 command rejection은 worker를 유지한다. 연결 종료, timeout, 또는 overlong
line은 해당 worker만 폐기한다. reconnect는 깨끗한 새 시도다. worker는 15초 idle 또는 120초 전체
session 제한을 넘기면 종료된다.

제출 형식은 SCAN{...}이며 check_format.py는 형식만 검사한다.
