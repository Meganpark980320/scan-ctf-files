# Settlement Retry

The recovery desk exposes four linked dockets—review, hold, escrow, and reserve—per fresh TCP
worker. A valid external compliance attestation is intentionally unavailable in this sandbox.
Make the banner's target case settle to a beneficiary you control and submit the returned flag.

This is a source-less, live native service. Use only the participant files and the endpoint
supplied by the operator; do not expect an ELF, source archive, debugger, or state shared across
reconnects. The public wire protocol provides evidence receipts and read-only route certificates,
but does not expose raw retained-storage views.
