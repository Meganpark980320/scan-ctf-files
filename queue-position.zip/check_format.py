#!/usr/bin/env python3
"""Participant-side syntax checker for Queue Position; it contains no answer data."""

from __future__ import annotations

import re
import sys


FLAG = re.compile(r"^SCAN\{[a-z0-9]+(?:-[a-z0-9]+)*\}$")


def is_valid(candidate: str) -> bool:
    return bool(FLAG.fullmatch(candidate))


def main() -> int:
    candidate = sys.stdin.read().rstrip("\r\n")
    if is_valid(candidate):
        print("format looks valid")
        return 0
    print("expected: SCAN{lowercase-entity-slug}")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
