# Queue Position

브리지 사고 조사 중입니다. 출발 체인 Kestrel에서 확정된 예치 로그 하나가
`source_events.json`의 `investigation.confirmed_bridge_log`에 핀으로 지정되어 있습니다.
그 자금은 Lumen의 OTC/정산 옴니버스 계정들을 여러 번 통과했고, 같은 시각 같은 금액의
다른 브리지 도착분과 실패한 재시도도 남아 있습니다.

목표는 그 **확정된 출발 로그의 원금**이 관측 종료 시점에 가장 많이 남아 있는 거래소
핫월렛 엔터티를 찾는 것입니다.

## 정확한 원장 규칙

1. 출발 이벤트 배열에서 `(tx_hash, log_index)`가 핀과 정확히 일치하는 성공한
   `BRIDGE_DEPOSIT`를 찾고, 그 `message_id`를 `M`이라고 둡니다. 금액, 시간, 같은
   트랜잭션의 다른 로그로 대신 고르면 안 됩니다.
2. `destination_events.json`의 모든 이벤트를 다음 키 오름차순으로 정렬합니다.

   ```text
   (block_number, transaction_index, log_index, tx_hash)
   ```

3. 관측 시작 전에는 모든 주소의 USDX FIFO 큐가 비어 있습니다. `amount_units`는 정수
   base unit(`decimals: 6`)이며, 부동소수점 연산을 쓰지 마세요.
4. 정렬된 이벤트를 앞에서부터 한 번씩 적용합니다.

   - `SETTLEMENT_CREDIT`가 `SUCCESS`이면 `to`의 큐 **뒤**에 새 비대상(non-target) lot을
     추가합니다.
   - `BRIDGE_EXECUTION`이 `EXECUTED`이면 `recipient`의 큐 **뒤**에 새 lot을 추가합니다.
     그 lot은 `message_id == M`일 때만 대상(target) lot이고, 다른 모든 message는
     비대상 lot입니다.
   - `TOKEN_TRANSFER`가 `SUCCESS`이면 `from`의 큐 **앞**에서 `amount_units`만큼을 FIFO로
     꺼냅니다. 잘린 lot 조각도 원래의 대상/비대상 표식을 보존합니다. 꺼낸 조각들은
     같은 순서 그대로 `to`의 큐 **뒤**에 추가합니다.
   - `REVERTED` 이벤트는 어떤 큐도 바꾸지 않습니다.

   `SETTLEMENT_CREDIT`, `BRIDGE_EXECUTION`, `TOKEN_TRANSFER` 이외의 이벤트 종류는 없습니다.
   모든 이벤트는 하나의 동일한 destination USDX 자산을 다룹니다.
5. 마지막 이벤트 뒤, `entity_labels.json`에서 `role`이 `exchange_hot_wallet`인 각 주소의
   큐에 남은 **target lot의 합**을 계산합니다. 그 값이 엄격하게 가장 큰 엔터티의
   `entity_slug`가 답입니다.

즉, 한 핫월렛의 **총 입금액**이나 한 번의 스윕 금액이 답이 아닙니다. 이미 들어 있던
clean/orphan lot, 부분 소비, 이후 출금까지 반영한 **최종 FIFO 보유량**을 비교해야 합니다.

## 제출 형식

```text
SCAN{<lowercase_entity_slug>}
```

`check_format.py`는 형태만 확인합니다. 네트워크를 사용하지 마세요.
