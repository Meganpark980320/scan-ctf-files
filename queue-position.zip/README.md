# Queue Position — 참가자 안내

이 디렉터리의 JSON만으로 풀 수 있는 오프라인 포렌식 문제입니다. RPC, 익스플로러,
외부 주소 라벨은 필요하지도 허용되지도 않습니다.

- `case.json` — 조사 범위와 이벤트 정렬 키
- `source_events.json` — 확정된 출발 브리지 로그를 포함한 Kestrel 이벤트
- `destination_events.json` — Lumen의 완전한 USDX 정산 원장
- `entity_labels.json` — 답 후보인 거래소 핫월렛 주소와 제출용 slug
- `schema.json` — 파일 형식과 FIFO 규칙의 기계 판독용 요약
- `check_format.py` — 플래그 문법만 확인합니다. 답을 판정하지는 않습니다.

배열의 현재 순서는 의미가 없습니다. `case.json`의 `ordering` 순서로 정렬한 뒤,
문제 본문의 원장 규칙을 그대로 적용하세요.
