# Finality Mirage

조사 대상의 bridge 출금이 여러 fork와 relay 기록에 겹쳐 있습니다. `case.json`에는
피해자의 sender, token, stolen amount와 관측된 source receipt `(tx_hash, log_index)`가
있습니다. 같은 receipt가 reorg된 orphan branch에도 나타나며, 정식 epoch 안에는 byte-identical
payload를 가진 별도 outbox emission도 있습니다. destination에는 orphan root의 성공 claim도
있습니다.

목표는 정식 message에서 유래한 lot을 FIFO로 끝까지 추적한 뒤, 마지막에 가장 많은
target-origin unit을 가진 `exchange_hot_wallet`의 `entity_slug`를 찾아
`SCAN{entity-slug}`로 제출하는 것입니다.

## 반드시 적용할 규칙

1. `headers.json`에서 genesis-reachable leaf를 구하세요. cumulative work가 가장 큰 tip이
   정식 chain이고 동점이면 **hash가 lexical하게 더 큰 tip**이 이깁니다. height가 더 긴
   branch가 정식이라는 뜻은 아닙니다.
2. 정식 header에 실린 `OUTBOX_MESSAGE` 중 case의 sender/token/amount/**source receipt
   coordinate**와 맞는 것을 고르고, 같은 epoch의 message들로 root를 재계산하세요. 해당
   `OUTBOX_ROOT` commit도 정식 chain에 있어야 합니다.
3. destination의 `CLAIM`은 source message id와 source `leaf_index`를 직접 제공하지 않고
   payload, ordered proof, root를 갖습니다. source에서 고른 occurrence의 `leaf_index`로
   기대되는 proof 방향/형제 hash를 계산해 비교하고, [protocol.md](protocol.md)의 proof 검증과
   `ROOT_ACCEPTED` triple `(epoch, root, source_block_hash)` 일치를 모두 통과한 **EXECUTED**
   claim만 target lot으로 표시합니다. 동일 payload의 다른 outbox occurrence도 valid proof와
   함께 실행되므로 payload field만으로는 둘 중 하나를 고를 수 없습니다.
4. `destination_events.json`의 token state event는
   `(block_number, transaction_index, log_index, tx_hash)` 오름차순으로 적용합니다.
   성공한 모든 `SETTLEMENT_CREDIT`와 모든 `CLAIM`은 recipient queue 뒤에 새 lot을 붙입니다.
   다만 3번의 canonical proof 조건을 통과한 claim 하나에만 target-origin 표시를 붙입니다.
   성공한 `TOKEN_TRANSFER`는 sender queue의 앞 lot부터 정확히 FIFO로 떼어 recipient queue
   뒤에 붙입니다. 실패/reverted event는 무시합니다.
5. 마지막에는 `entity_labels.json`에서 role이 `exchange_hot_wallet`인 entity만 비교합니다.
 raw 입금 총액이나 가장 큰 단일 transfer는 답이 아닙니다.

`REVERTED` event는 FIFO 상태를 바꾸지 않습니다. `EXECUTED` claim은 모두 destination ledger에
credit되지만, canonical source occurrence에 대응하는 proof 하나만 target-origin입니다.

배열의 파일상 순서는 의미가 없습니다. 모든 amount는 정수 최소 단위입니다.

형식 예시:

```text
SCAN{moss-quay-a1b2c3d4}
```
