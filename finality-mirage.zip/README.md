# Finality Mirage / participant files

`problem.md`부터 읽고 `protocol.md`의 SHA-256/Merkle 규칙을 구현하세요. `schema.json`은
필드와 상태 값을, `check_format.py`는 제출 문자열의 형식만 제공합니다.

이 자료에는 정답 검증기나 source message id를 claim으로 연결하는 mapping이 없습니다.
