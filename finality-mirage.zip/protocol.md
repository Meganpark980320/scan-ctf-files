# Finality Mirage protocol v1

모든 hash는 lower-case `0x` + 64 hex 문자다. payload의 byte 표현은 Python의 아래와
동일한 **canonical JSON**이다. 즉 UTF-8, `sort_keys=True`, `ensure_ascii=True`, 공백 없는
separator `(',', ':')`를 쓴다.

```python
encoded = json.dumps(payload, sort_keys=True, ensure_ascii=True,
                     separators=(',', ':')).encode('utf-8')
leaf = sha256(b'FINALITY-MIRAGE/LEAF/v1\x00' + encoded).digest()
parent = sha256(b'FINALITY-MIRAGE/NODE/v1\x00' + left + right).digest()
```

한 epoch의 `OUTBOX_MESSAGE`는 `leaf_index` 오름차순으로 leaf 배열을 만든다. 인접한
두 node를 왼쪽·오른쪽 순서로 parent로 묶고, 한 level의 마지막 node에 짝이 없으면 그
node를 자신과 한 번 더 묶는다. `proof`는 leaf에서 root 방향 순서이며, 각 항목의
`position`이 `left`면 `hash || current`, `right`면 `current || hash`다.

작은 hash 검증 vector:

```text
payload JSON = {"amount_units":7,"destination_chain_id":2,"nonce":1,"recipient":"0x1111111111111111111111111111111111111111","sender":"0x2222222222222222222222222222222222222222","source_chain_id":1,"token":"0x3333333333333333333333333333333333333333"}
leaf          = 0x854f2520654337e59ab5005a9d0bedd987fd3181f6f2e00f09cff869bf6274b0
one-leaf root = 0x854f2520654337e59ab5005a9d0bedd987fd3181f6f2e00f09cff869bf6274b0
two equal leaves parent = 0x84bb68fc31850a2403a34711f5f93a675a01756a6dd146493a1bc83e1597b18c
```

`ROOT_ACCEPTED`가 `TRUSTED`여도 source block이 정식 체인의 `OUTBOX_ROOT` commit인지
별도로 확인해야 한다. `case.json`의 source receipt coordinate로 canonical source
`OUTBOX_MESSAGE` occurrence를 하나 고른 뒤, 그 source record의 `leaf_index`와 epoch leaf
배열로 **기대 proof path**를 재구성한다. destination claim은 source leaf index를 싣지 않는다.
admissible target claim은 다음을 모두 만족한다.

1. `status == "EXECUTED"`이고 proof가 선택한 source occurrence의 기대 path와 byte-for-byte
   같으며, 이를 재계산한 값이 claim의 `root`와 같다.
2. 같은 `(epoch, root, source_block_hash)`인 `ROOT_ACCEPTED`가 `TRUSTED`다.
3. 같은 triple인 `OUTBOX_ROOT`가 정식 source chain header에 있다.

서로 다른 outbox emission은 payload가 byte-identical할 수 있다. 이때 leaf hash도 같지만
tree 안의 occurrence와 ordered sibling path는 다르다. destination claim에는 source
`message_id`나 `leaf_index`가 제공되지 않으므로, payload equality 뒤에도 이 path 비교가
필수다. FIFO replay에서는 모든 `EXECUTED` claim이 일반 lot을 credit하지만, 위 세 조건을
통과한 유일한 claim만 target-origin lot으로 표시한다. `REVERTED` event는 FIFO 상태를
바꾸지 않는다.
