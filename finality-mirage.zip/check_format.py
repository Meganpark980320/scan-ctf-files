#!/usr/bin/env python3
"""Public syntax-only checker; it deliberately does not reveal the entity."""

from __future__ import annotations

import re

FLAG = re.compile(r"\ASCAN\{[a-z0-9]+(?:-[a-z0-9]+)*\}\Z")


def is_valid(candidate: str) -> bool:
    return bool(FLAG.fullmatch(candidate))


if __name__ == "__main__":
    import sys
    print("valid format" if len(sys.argv) == 2 and is_valid(sys.argv[1]) else "invalid format")
