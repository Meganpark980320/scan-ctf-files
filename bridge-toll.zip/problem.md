# Bridge Toll

An incident responder confirmed that a stolen USDX position was sent through the
Kestrel-to-Lumen bridge. On the destination side a **relay retry** and a
**near-identical bridge transfer of the same size** landed around the same time, so the
cash-out attribution is contested — several deliveries look plausible and only one is
actually the confirmed deposit's.

Everything needed for the investigation is in this participant bundle. Do **not** use a
live explorer or RPC endpoint.

## Given

- `source_events.json` — source-chain (Kestrel) events. `investigation.confirmed_bridge_log`
  pins the one finalized deposit you must start from, by its `(tx_hash, log_index)`
  coordinate.
- `destination_events.json` — destination-chain (Lumen) events: bridge deliveries and
  token movements.
- `entity_labels.json` — known addresses and their entity slugs (exchanges' hot wallets,
  the bridge, …). The intermediate cash-out address is intentionally unlabeled.
- `schema.json` documents the shapes; `check_format.py` only checks the flag shape.

## Objective

Follow the confirmed deposit to the destination chain, establish which delivery is
genuinely **its** delivery (not the retry, not the look-alike), trace where those funds
were cashed out, and identify the **exchange entity** that received them. Submit its
entity slug:

```text
SCAN{<lowercase_entity_slug>}
```
Format: `^SCAN\{[a-z0-9-]+\}$`.

## Notes

- Self-contained; no external data. The JSON arrays are **not** in chronological order —
  each event carries the fields you need to order and correlate them yourself.
- A retry and a same-amount look-alike are in the data on purpose. Matching on amount or
  timestamp alone will put you on the wrong delivery — the source and destination sides of
  a bridge transfer correspond in a stronger way than that.
- Only movements that actually settled change the ledger; attempts that did not are noise.
- `amount_units` are integer USDX base units (`decimals: 6`) — never use floats. The
  destination asset is the bridged USDX representation on Lumen, so its token contract
  address differs from the source-chain USDX.
