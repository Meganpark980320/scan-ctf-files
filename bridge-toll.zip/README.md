# Bridge Toll — participant files

Start with `problem.md`.

- `source_events.json`: source-chain event export and the confirmed bridge-log coordinate.
- `destination_events.json`: destination-chain bridge execution attempts and token transfers.
- `entity_labels.json`: labels for known destination hot wallets.
- `schema.json`: field definitions and ordering rules.
- `check_format.py`: checks only the flag syntax; it does not know the answer.

All data needed to solve is included. Do not use a public explorer or live RPC endpoint.
