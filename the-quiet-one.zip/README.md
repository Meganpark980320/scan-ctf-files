# The Quiet One  (tracing / clustering · medium)

## Scenario
A DeFi protocol on a private EVM chain was drained in a single exploit. Our monitoring
snapshotted the **entire chain state** right after the attacker finished moving the funds.

The attacker layered the stolen ETH through several hops — splitting it, pushing part of it
through a busy churn of throwaway wallets and part through a slow chain of quiet ones — before
pulling the pieces back together into one wallet they intend to sit on.

The chain also carries plenty of money that has nothing to do with the theft (large OTC-style
transfers, routine wallet noise). Your job is to follow **the victim's funds specifically** and
find where they come back together.

## Given
- `state.json.gz` — Foundry `dump-state` snapshot (accounts + full transaction history).
- Drained protocol (start here): `0xb79318670d3be85efc9ea2eac02b8bc54748bb5a`
- Exploit tx: `0x95cd603fe577fa9548ec0c9b50b067566fe07c8af6acba45f6196f3a15d511f6`

## Task
Trace the stolen funds from the drained protocol through the laundering hops and identify the
**wallet where they reconverge** — the address now holding the consolidated proceeds. Each hop
loses a little to gas and the funds are split along the way, so the reconverged amount is **not**
a round number and won't equal the amount originally drained.

## Flag
```
SCAN{reconvergence_wallet}
```
Format: `reconvergence_wallet: ^0x[0-9a-f]{40}$` (lowercase, 0x included)

## Notes
- The chain state is self-contained. No external explorer / live data needed.
- Not every large or busy wallet on this chain is connected to the exploit — provenance from the
  drained protocol is what decides it.
