# The Quiet One  (tracing / clustering · medium)

## Scenario
A DeFi protocol on a private EVM chain was drained in a single exploit. Our monitoring
snapshotted the **entire chain state** right after the attacker finished moving the funds.

The attacker knew they were being watched, so they made the money **loud in one place and
quiet in another** — hoping investigators would chase the obvious pile and miss the real one.

Find the attacker's **final consolidation wallet** — the address that actually holds the
stolen funds now.

## Given
- `state.json.gz` — Foundry `dump-state` snapshot (accounts + full transaction history).
- Drained protocol (start here): `0x9e67923ea2a991540fd358f28f56ce5b72bdb34c`
- Exploit tx: `0x95cd603fe577fa9548ec0c9b50b067566fe07c8af6acba45f6196f3a15d511f6`

## Task
Identify the single EOA that ended up holding the full stolen amount.

## Flag
```
SCAN{final_consolidation_wallet}
```
Format: `final_consolidation_wallet: ^0x[0-9a-f]{40}$` (lowercase, 0x included)

## Notes
- The chain state is self-contained. No external explorer / live data needed.
- Beware the obvious. The largest single transfer, the busiest address, and the
  highest-balance account are **not** the answer.
