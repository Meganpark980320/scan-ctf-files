# Counter  (crypto · medium)

A wallet's signing device used a **monotonic counter** as its ECDSA "random" nonce instead
of real randomness. So two consecutive signatures were produced with nonces `k` and `k+1`.

`challenge.json` gives the wallet's public key and two such consecutive signatures. Unlike a
plain nonce-reuse, the two `r` values are **different** — but the +1 relationship between the
nonces is just as fatal.

## Objective

Recover the wallet's **private key** `d` and submit it:

```text
SCAN{0x<private_key_hex>}
```
Format: `^SCAN\{0x[0-9a-f]{64}\}$` (lowercase, 64 hex, 0x included).

## Notes
- Standard secp256k1; `n` is the curve order. Values are 32-byte big-endian hex.
- `z` is the signed message hash, `(r, s)` the signature. The nonces satisfy `k2 = k1 + 1`.
- Verify: `d · G` must equal the given public key.
