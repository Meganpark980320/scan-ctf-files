// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @title ProvablyFair
/// @notice A "provably fair" number vault. It opens only for whoever can name the fair
///         number — drawn from unbiased on-chain entropy at the exact moment you call.
///         Nobody can predict it. The odds of guessing are 1 in 2^256.
///
///         Go on. Name your number.
contract ProvablyFair {
    bool private _open;

    /// @notice Name the fair number and open the vault.
    function open(uint256 number) external {
        uint256 fair = uint256(
            keccak256(abi.encodePacked(block.prevrandao, blockhash(block.number - 1), msg.sender))
        );
        require(number == fair, "not your lucky day");
        _open = true;
    }

    function isSolved() external view returns (bool) {
        return _open;
    }
}
