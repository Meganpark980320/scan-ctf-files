# Provably Fair  (on-chain · exploit)

This vault runs a **provably fair** draw. It opens only for whoever can name the fair
number — drawn from unbiased on-chain entropy at the exact moment you call. Nobody can
predict it; the odds of guessing are **1 in 2^256**.

Open the vault anyway.

## How to play
Live challenge — you interact with a real EVM node.

1. Launch your instance:
   ```
   curl -s -X POST https://pf-host-production.up.railway.app/launch -H "Content-Type: application/json" -d '{"team":"YOURNAME"}'
   ```
   You get your vault `address`, a funded `player_key`, and the RPC URL.
2. Use that URL as an EVM RPC (cast / forge / web3) to interact and to **deploy your own
   contracts**. Read `ProvablyFair.sol` (included) closely — especially *where* the "fair"
   number comes from.
3. When your vault reports `isSolved() == true`, collect the flag:
   ```
   curl -s "https://pf-host-production.up.railway.app/flag?team=YOURNAME"
   ```

Flag format: `SCAN{...}`.
