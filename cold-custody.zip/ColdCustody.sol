// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/// @title ColdCustody
/// @notice A "self-custody recovery escrow." A drainer parked stolen funds here and claims
///         they can only be released to the ORIGINAL victim — whoever can prove knowledge of
///         the victim's secret (its keccak256 commitment is public below).
///
///         You don't have the victim's secret. Recover the funds anyway.
contract ColdCustody {
    address public owner;                 // administrator (set once via initialize)
    bool public initialized;
    bytes32 public immutable victimCommitment; // keccak256(secret) — "prove you're the victim"
    bool private _recovered;

    event Initialized(address indexed owner);
    event Recovered(address indexed by);

    /// @dev Deployed with only the victim commitment. Ownership is meant to be established by a
    ///      follow-up initialize() call from the deploy pipeline.
    constructor(bytes32 commitment) {
        victimCommitment = commitment;
    }

    /// @notice One-time ownership setup, intended to be called by the deployer right after deploy.
    function initialize(address _owner) external {
        require(!initialized, "already initialized");
        initialized = true;
        owner = _owner;
        emit Initialized(_owner);
    }

    // ---------------------------------------------------------------------
    // The advertised recovery path: prove you are the original victim.
    // ---------------------------------------------------------------------
    function recoverAsVictim(bytes32 secret) external {
        require(keccak256(abi.encodePacked(secret)) == victimCommitment, "not the victim");
        _recovered = true;
        emit Recovered(msg.sender);
    }

    // ---------------------------------------------------------------------
    // Administrative recovery, restricted to the owner.
    // ---------------------------------------------------------------------
    function recover() external {
        require(msg.sender == owner, "only owner");
        _recovered = true;
        emit Recovered(msg.sender);
    }

    function isSolved() external view returns (bool) {
        return _recovered;
    }
}
