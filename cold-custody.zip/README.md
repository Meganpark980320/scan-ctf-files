# Cold Custody  (on-chain · exploit)

A drainer parked the stolen funds in a self-custody "recovery escrow" and left a note:
*the vault only releases to the original victim — whoever can prove they know the victim's
secret (its keccak256 commitment is public in the contract).*

You are the investigator. You do **not** have the victim's secret. Recover the funds anyway.

## How to play
This is a **live** challenge — you interact with a real EVM node.

1. Launch your instance:
   ```
   curl -s -X POST https://cc-host-production.up.railway.app/launch -H "Content-Type: application/json" -d '{"team":"YOURNAME"}'
   ```
   You get your escrow `address`, a funded `player_key`, and the RPC URL.
2. Use that URL as an EVM RPC (cast / web3.py / ethers) to interact with your escrow.
   Read `ColdCustody.sol` (included) carefully.
   ```
   cast call <address> "isSolved()(bool)" --rpc-url https://cc-host-production.up.railway.app/
   ```
3. When your escrow reports `isSolved() == true`, collect the flag:
   ```
   curl -s "https://cc-host-production.up.railway.app/flag?team=YOURNAME"
   ```

Flag format: `SCAN{...}`.
